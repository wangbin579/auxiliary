#! /usr/bin/python3

import os
import time
import signal
import sys
import pdb
import traceback

TERM_YELLOW = '\x1b[1;33;40m'
TERM_GREEN = '\x1b[1;32;40m'
TERM_RED = '\x1b[1;31;40m'
TERM_DEFAULT = '\x1b[0m'

class CetusError(Exception):
    pass
class CetusTestFailed(Exception):
    pass

def get_test_scripts(filelist):
    if len(filelist) == 1 and os.path.isdir(filelist[0]):
        basedir = filelist[0]
        skipfile = basedir + os.sep + 'tests_to_skip.txt'
        if os.path.exists(skipfile):
            with open(skipfile) as f:
                blacklist = f.read().split('\n')
        else:
            blacklist = []

        scripts = [basedir + '/t/' + x for x in os.listdir(basedir + '/t')
                   if x.endswith('.test') and x not in blacklist]
        return scripts
    else:
        return filelist

def need_ps_flag(name):
    with open(name) as f:
        for line in f:
            if line.find('able_ps_protocol') > 0:
                return True
    return False

def env(key, default=""):
    return str(os.environ.get(key, default))

def run_mysqltest(script):
    options = {
        'user'      : env('MYSQL_USER', 'test'),
        'password'  : env('MYSQL_PASSWORD', 'test'),
        'host'      : env('PROXY_HOST', '127.0.0.1'),
        'port'      : env('PROXY_PORT', 6360),
    }
    opt_str = " ".join(['--'+k+'='+v for k,v in options.items()])    
    cmd = 'mysqltest ' + opt_str + ' --verbose --logdir=./'
    cmd += ' --test-file=' + script
    result = script.replace('/t/', '/r/').replace('.test', '.result')
    cmd += ' --result-file=' + result
    if need_ps_flag(script):
        cmd += ' --ps-protocol'

    if os.system(cmd) == 0:
        return True
    else:
        return False

def read_pid(pidfile):
    with open(pidfile) as f:
        pid = f.readline()
        try:
            x = int(pid)
            return x
        except ValueError:
            return -1

def pid_exists(pid):
    """Check whether pid exists in the current process table."""
    import errno
    if pid < 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError as e:
        return e.errno == errno.EPERM
    else:
        return True

def wait_proc_up(pidfile):
    rounds = 0
    time.sleep(1)
    while not os.path.exists(pidfile):
        time.sleep(2)
        rounds += 1
        print("pidfile-wait:", rounds, "rounds")
        if rounds > 10:
            print("proxy failed to start: no pidfile:", pidfile)
            return False, -1

    pid = read_pid(pidfile)
    rounds = 0
    while not pid_exists(pid):
        time.sleep(0.2)
        rounds += 1
        print('pid-wait:', rounds, 'rounds')
        if rounds > 5:
            print("proxy failed to start: no such pid", pid)
            return False, -1

    time.sleep(1)
    return True, pid

def make_shard_start_cmd():
    cetus_root = env('CETUS_INSTALL_PREFIX')
    options = {
        'proxy-address'       : env('PROXY_HOST', '127.0.0.1')+':'+env('PROXY_PORT', 6360),
        'pid-file'            : os.getcwd()+os.sep+env('PROXY_PIDFILE', 'cetus.pid'),
        'plugin-dir'          : env('PROXY_LIBPATH', cetus_root + '/lib/cetus/plugins'),
        'default-username'    : env('MYSQL_USER'),
        'default-db'          : env('DEFAULT_DB'),
        'default-pool-size'   : env('DEFAULT_POOL_SIZE', 10),
        'admin-username'      : env('MYSQL_USER', 'test'),
        'admin-password'      : env('PROXY_ADMIN_PASSWORD', 'password'),
        'admin-address'       : env('PROXY_HOST', '127.0.0.1')+':'+env('PROXY_ADMIN_PORT'),
        'disable-threads'     : env('DISABLE_THREADS', 'false'),
        'log-level'           : 'debug',
        'log-file'            : os.getcwd()+os.sep+env('PROXY_LOG_FILE', "cetus.log"),
        'config-remote'       : env('CONFIG_REMOTE', 'true'),
        'proxy-id'            : env('PROXY_ID'),
        'config-host'         : env('CONFIG_HOST'),
        'config-port'         : env('CONFIG_PORT'),
        'config-user'         : env('CONFIG_USER'),
        'config-pass'         : env('CONFIG_PASS'),
        'config-db'           : env('CONFIG_DB'),
    }
    opt_str = " ".join(['--'+k+'='+v for k,v in options.items()])
    opt_str += " --plugins=shard --plugins=admin"
    return cetus_root + os.sep + 'bin/cetus ' + opt_str

def make_rw_start_cmd():
    cetus_root = env('CETUS_INSTALL_PREFIX')
    options = {
        'proxy-backend-addresses' : env('MYSQL_HOST', '127.0.0.1')+':'+env('MYSQL_PORT', 3306),
        'proxy-read-only-backend-addresses' : env('MYSQL_RO_HOST', '127.0.0.1')+':'+env('MYSQL_RO_PORT', 3306),
        'proxy-address'       : env('PROXY_HOST', '127.0.0.1')+':'+env('PROXY_PORT', 6360),
        'pid-file'            : os.getcwd()+os.sep+env('PROXY_PIDFILE', 'cetus.pid'),
        'plugin-dir'          : env('PROXY_LIBPATH', cetus_root + '/lib/cetus/plugins'),
        'default-username'    : env('MYSQL_USER'),
        'default-db'          : env('DEFAULT_DB'),
        'default-pool-size'   : env('DEFAULT_POOL_SIZE', 10),
        'admin-username'      : env('ADMIN_USER', 'root'),
        'admin-password'      : env('ADMIN_PASSWORD', 'password'),
        'admin-address'       : env('PROXY_HOST', '127.0.0.1')+':'+env('PROXY_ADMIN_PORT'),
        'disable-threads'     : env('DISABLE_THREADS', 'false'),
        'user-pwd'            : env('PROXY_USER_PWD'),
        'app-user-pwd'        : env('PROXY_APP_USER_PWD'),
        'log-level'           : 'debug',
        'log-file'            : os.getcwd()+os.sep+env('PROXY_LOG_FILE', "cetus.log"),
    }
    opt_str = " ".join(['--'+k+'='+v for k,v in options.items()])
    opt_str += " --plugins=proxy --plugins=admin"
    return cetus_root + os.sep + 'bin/cetus ' + opt_str

def make_start_cmd():
    test_type = os.environ.get('CETUS_TEST_TYPE')
    if test_type == "shard":
        return make_shard_start_cmd()
    elif test_type == "rw":
        return make_rw_start_cmd()
    else:
        return make_shard_start_cmd()

def parse_pidfile_name(cmd):
    i = cmd.rfind('--pid-file')
    if i == -1:
        return None
    text = cmd[i+10:]
    text = text.lstrip('= ')
    i = text.find(' ')
    if i == -1:
        i = None
    return text[:i]

def start_cetus(cmd):
    pidfile = parse_pidfile_name(cmd)

    #remove the old pidfile silently
    try:
        os.remove(pidfile)
    except OSError:
        pass

    rc = os.system(cmd + ' &')
    if rc != 0:
        print(TERM_RED+'os.system returns', rc, TERM_DEFAULT)
        return False, -1

    return wait_proc_up(pidfile)

def stop_cetus(pid):
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return False
    else:
        rounds = 0
        while pid_exists(pid):
            time.sleep(0.2)
            rounds += 1
            if rounds > 50:
                print(TERM_RED+"failed to stop pid:", pid,TERM_DEFAULT)
                return False
        return True

def test_script(script, cmd):
    rc = start_cetus(cmd)
    if not rc[0]:
        print(TERM_RED+'error: cannot start proxy', TERM_DEFAULT)
        raise CetusError
    pid = rc[1]

    rc = run_mysqltest(script)
    if not rc:
        print(TERM_RED+'error: test failed:', script, TERM_DEFAULT)
        stop_cetus(pid)
        raise CetusTestFailed

    stop_cetus(pid)

def check_environ(user_env):
    if user_env.get('CETUS_INSTALL_PREFIX') is None:
        print(TERM_YELLOW+'CETUS_INSTALL_PREFIX is required', TERM_DEFAULT)
        raise CetusError
    if user_env.get('CETUS_TEST_TYPE') is None:
        name = sys.argv[1] # try guess test type
        user_env['CETUS_TEST_TYPE'] = 'rw' if name.startswith('base') else 'shard'
        print(TERM_YELLOW+'CETUS_TEST_TYPE not set, default to "shard"', TERM_DEFAULT)
    user_env = {k : str(v) for k, v in user_env.items()}
    os.environ.update(user_env)

def parse_options():
    options = [a for a in sys.argv if a.startswith('-')]
    if options:
        sys.argv = [a for a in sys.argv if a not in options]

    # we have only one cmdline option, -H for (halt on error)
    if options and '-H' in options:
        return True
    else:
        return False

usage = '''
Usage:
  run_cetus_test.py testdir
    testdir/t/* will be run

  run_cetus_test.py testdir/t/test_a.test testdir/t/test_b.test
    test_a.test and test_b.test will be run, compare result with testdir/r/xx
'''

def run(env_in, cmd = None):
    if len(sys.argv) == 1:
        print(usage)
        exit(1)

    check_environ(env_in)

    if cmd is None:
        cmd = make_start_cmd()
    print('starting with:', cmd)

    halt_on_error = parse_options()
    failed_scripts = []

    scripts = get_test_scripts(sys.argv[1:])
    for s in scripts:
        try:
            test_script(s, cmd)
        except CetusTestFailed:
            if halt_on_error:
                print('starting cmd:', cmd)
                exit(1)
            else:
                failed_scripts.append(s)
        except Exception as e:
            traceback.print_exc()
            exit(1)

    if failed_scripts:
        ratio = '{} in {}'.format(len(failed_scripts), len(scripts))
        print(TERM_YELLOW+'Some tests failed({}): '.format(ratio), ' '.join(failed_scripts), TERM_DEFAULT)
    else:
        print(TERM_GREEN+'Test OK,', len(scripts), 'scripts', TERM_DEFAULT)
