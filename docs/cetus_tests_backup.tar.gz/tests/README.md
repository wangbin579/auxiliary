# resurgence_tests

We recommand to use master-slave mode to run tests.
